/* © 2026 Ali Arıkoğlu. Tüm hakları saklıdır. */
/* Bireysel rekor, haftalık/genel sıralama ve Pekiştiriyorum turu (v15 taslak).
   Kurallar: sıralamayı yalnız doğru sayısı belirler; süre yalnız telefonda kalır; skoru yalnız Uyguluyorum yazar.
   Öğreniyorum, Pekiştiriyorum ve oda yarışı sıralamaya yazmaz. Tasarım: claude/oyun-siralama-tasarimi.md */
'use strict';
const RK_TERM='2026-2027', RK_VERSION=1;
const RK_SUBJ={baharat:'bh','mutfak-araclari':'ma','bulasik-makinesi-temizligi':'bl'};
const RK_MCQ={
 'mutfak-araclari':['Tabaklar ve kâseler', 'Bardaklar ve fincanlar', 'Çatal, bıçak ve kaşıklar', 'Servis araçları', 'Pişirme kapları ve tavalar', 'Hazırlık ve doğrama araçları', 'Ölçme, süzme, aktarma ve kontrol araçları', 'Hamur ve tatlı araçları', 'Pişirme ve ısıtma cihazları', 'Hazırlık cihazları', 'Saklama araçları ve artan yemek', 'Temizlik araçları', 'Koruyucular', '1. Bölüm · Bölüm sonu', '2. Bölüm · Bölüm sonu', '3. Bölüm · Bölüm sonu'],
 'bulasik-makinesi-temizligi':['Bulaşık Yıkama ve Atık Yönetimi · Bütün bölümler'],
 'beslenme-ilkeleri':['Beslenme İlkeleri · Bütün bölümler'],
 'baharat':['Baharatlar · Bütün bölümler']
};
/* Kurallardaki tablo listesiyle aynı olmalı. İçerikteki soru/kart sayısı tutmazsa o tablo sıralamaya yazmaz. */
const RK_BOARDS=(()=>{const a=[];
 for(let i=1;i<=8;i++)a.push({id:'bh-e'+i,subject:'baharat',kind:'match',set:i,total:12,label:i+'. takım · Eşleştirme'});
 for(let i=1;i<=12;i++)a.push({id:'ma-e'+i,subject:'mutfak-araclari',kind:'match',set:i,total:12,label:i+'. takım · Eşleştirme'});
 a.push({id:'bl-e1',subject:'bulasik-makinesi-temizligi',kind:'match',set:1,total:12,label:'1. takım · Eşleştirme'});
 a.push({id:'kv-basit',subject:'kuver',kind:'kur',lvl:1,total:4,label:'Basit Kuver · Kuveri Kur',gizli:true});
 a.push({id:'kv-tabldot',subject:'kuver',kind:'kur',lvl:3,total:6,label:'Tabldot Kuver · Kuveri Kur',gizli:true});
 const mt=[22, 18, 23, 5, 15, 15, 23, 9, 8, 4, 4, 6, 5, 17, 15, 9];
 RK_MCQ['mutfak-araclari'].forEach((g,i)=>a.push({id:'ma-q'+String(i+1).padStart(2,'0'),subject:'mutfak-araclari',kind:'mcq',group:g,total:mt[i],label:g+' · Sorular'}));
 a.push({id:'oy-kapisma',subject:'oyun',kind:'win',total:999,label:'1’e 1 Kapışma · kazanılan maç'});
 a.push({id:'oy-arena',subject:'oyun',kind:'win',total:999,label:'Er Meydanı (önceki sürüm) · kazanılan tur'});
 a.push({id:'oy-arena2',subject:'oyun',kind:'win',total:999,label:'Er Meydanı · kazanılan oyun'});
 a.push({id:'bl-s1',subject:'bulasik-makinesi-temizligi',kind:'mcq',group:RK_MCQ['bulasik-makinesi-temizligi'][0],total:65,label:'Bütün bölümler · Sorular'});
 a.push({id:'bs-s1',subject:'beslenme-ilkeleri',kind:'mcq',group:RK_MCQ['beslenme-ilkeleri'][0],total:145,label:'Bütün bölümler · Sorular'});
 a.push({id:'bh-s1',subject:'baharat',kind:'mcq',group:RK_MCQ['baharat'][0],total:104,label:'Bütün bölümler · Sorular'});
 a.push({id:'ar-puan',subject:'oyun',kind:'kutu',total:312,label:'Er Meydanı · en yüksek puan (tek oyun)'});
 [1,2,3,4].forEach(n=>a.push({id:'bh-k'+n,subject:'baharat',kind:'kutu',total:120,label:'Baharat Rafı · Kutu '+n+' (puan)'}));
 a.forEach(b=>{if(/^(ma|bh|bl)-e\d+$/.test(b.id))b.gizli=true;}); /* 12'li eşleştirme tabloları: bu üç konuda 12'li eşleştirme kalktı, tablolar sıralamada gösterilmez */
 return a;})();
const RK_SUBJECT_NAMES={baharat:'Baharatlar','mutfak-araclari':'Mutfak Araçları',kuver:'Kuver','bulasik-makinesi-temizligi':'Bulaşık Yıkama ve Atık Yönetimi','beslenme-ilkeleri':'Beslenme İlkeleri',oyun:'Kapışma ve Er Meydanı'};
const RK={cal:null,backend:null,busy:false,view:{board:null,period:'hafta',rows:null,state:'idle',err:''},msg:null};

/* ---------- Yardımcılar ---------- */
function rkBoard(id){return RK_BOARDS.find(b=>b.id===id)||null;}
function rkWeekNo(ms){return Math.floor(((ms||Date.now())+10800000+259200000)/604800000);}
function rkWeekLabel(w){const start=w*604800000-259200000,d=ms=>{const x=new Date(ms);return pad(x.getUTCDate())+'.'+pad(x.getUTCMonth()+1)+'.'+x.getUTCFullYear();};return d(start)+' – '+d(start+6*86400000);}
function rkTable(boardId,period,w){return RK_TERM+'~'+boardId+'~'+(period==='genel'?'genel':'w'+(w||rkWeekNo()));}
/* Sıralamada yalnız oyun adı (hazır karakter) görünür; gerçek ad tutulmaz. */
function rkName(n){return String(n||'').trim().replace(/\s+/g,' ').slice(0,40);}
function rkRandomId(){const c='abcdefghijklmnopqrstuvwxyz0123456789',b=crypto.getRandomValues(new Uint8Array(20));return Array.from(b,x=>c[x%c.length]).join('');}
function rkIds(){return ls('rk_ids',{});}
function rkPid(name,create){const m=rkIds();if(!m[name]&&create){m[name]=rkRandomId();lsSet('rk_ids',m);}return m[name]||null;}
function rkProfAll(){return ls('rk_prof',{});}
function rkProf(pid){return rkProfAll()[pid]||{status:'in',gen:0,synced:false};}
function rkProfSet(pid,v){const a=rkProfAll();a[pid]={...rkProf(pid),...v};lsSet('rk_prof',a);}
function rkBestAll(){return ls('rk_best',{});}
function rkQueue(){return ls('rk_queue',[]);}
function rkClean(){return ls('rk_clean',{});}
function rkCleanAdd(pid,table){const c=rkClean();c[pid]=c[pid]||[];if(!c[pid].includes(table))c[pid].push(table);lsSet('rk_clean',c);}
function rkCleanDel(pid,table){const c=rkClean();c[pid]=(c[pid]||[]).filter(t=>t!==table);if(!c[pid].length)delete c[pid];lsSet('rk_clean',c);}
function rkPekAll(){return ls('rk_pek',{});}
function rkPek(pid){return rkPekAll()[pid]||{};}
function rkPekSave(pid,v){const a=rkPekAll();a[pid]=v;lsSet('rk_pek',a);}
function rkRaceActive(){return typeof YR!=='undefined'&&YR.active;}
function rkBackend(){if(RK.backend)return RK.backend;if(window.REKOR_FAKE)RK.backend=window.REKOR_FAKE;else if(typeof RekorFirebase!=='undefined')RK.backend=new RekorFirebase(window.YARIS_FIREBASE_CONFIG);return RK.backend;}
function rkOnline(){return navigator.onLine!==false;}
function rkErrCode(e){return (e&&(e.code||e.message))||'';}

/* İçerikteki gerçek kart/soru sayısı tablo sınırıyla aynı mı? Değilse o tablo sıralamaya yazılmaz. */
function rkBoardValid(b){
 if(b.kind==='win'||b.kind==='kutu'||b.kind==='weekly'||b.dynamic)return true;
 if(b.kind==='kur')return typeof LEVELS!=='undefined'&&LEVELS[b.lvl]&&LEVELS[b.lvl].items.length===b.total;
 const d=CONTENT[b.subject];if(!d)return false;
 if(b.kind==='match')return d.matches.filter(x=>x.set===b.set).length===b.total;
 const saveSub=st.subject,saveOp=st.op;st.subject=b.subject;st.op='mcq';let n=0;try{const g=mcqGroups().find(x=>x.label===b.group);n=g?g.count:0;}finally{st.subject=saveSub;st.op=saveOp;}
 return n===b.total;
}
/* Biten oturumun tablosu. Hazırlık turları, yer değiştirme tekrarı ve puansız yoklama sıralamaya girmez. */
function rkBoardForSession(){
 const s=st.sess;if(!s||s.practice!=='check'||s.unranked)return null;
 if(st.op==='match'&&st.board&&st.board.size===12&&!st.board.variant&&RK_SUBJ[st.subject])return rkBoard(RK_SUBJ[st.subject]+'-e'+st.contentSet);
 if(st.op==='kur')return rkBoard(st.lvl===3?'kv-tabldot':st.lvl===1?'kv-basit':'');
 if(st.op==='mcq')return RK_BOARDS.find(b=>b.kind==='mcq'&&b.subject===st.subject&&b.group===st.mcqGroup)||null;
 return null;
}
function rkSessionDone(){
 const s=st.sess;if(!s||s.race)return false;
 if(st.op==='match')return !!(st.board&&(s.practice==='check'?st.board.checked:st.kDone));
 return !!st.kDone;
}

/* ---------- Sonucu işleme ---------- */
function rkSessionCorrect(){return st.sess.ok;}
function rkSessionDuration(){const s=st.sess;if(typeof s.duration==='number')return s.duration;return Math.round(s.qs.reduce((n,q)=>n+(Number(q.s)||0),0)*10)/10;}
function rkAfterAssessment(){
 const s=st.sess;s.rkDone=true;
 if(st.guest){RK.msg={sess:s.id,head:'Misafir oturumu',text:'Misafir oturumunda rekor ve sıralama kaydedilmez.',cloud:''};return;}
 const pid=rkPid(st.prof,true);
 rkPekFromAssessment(pid);
 const b=rkBoardForSession();if(!b)return;
 if(!rkBoardValid(b)){RK.msg={sess:s.id,head:'Sonucun kaydedildi.',text:'Bu çalışmanın içeriği güncellendiği için sonuç şimdilik sıralamaya yazılmıyor.',cloud:''};return;}
 const correct=rkSessionCorrect(),dur=rkSessionDuration(),now=new Date().toISOString();
 const all=rkBestAll(),mine=all[pid]||{},old=mine[b.id];
 let head,text;
 if(!old){head='İlk sonucun kaydedildi.';text='Bu denemede '+correct+' / '+b.total+' doğru.';}
 else if(correct>old.best){head='Yeni kişisel rekor!';text='Bu denemede '+correct+' / '+b.total+' doğru. Önceki en iyi sonucun: '+old.best+' / '+b.total+'.';}
 else if(correct===old.best){head='En iyi sonucuna ulaştın.';text='Bu denemede '+correct+' / '+b.total+' doğru.';}
 else{head='Sonucun kaydedildi.';text='Bu denemede '+correct+' / '+b.total+' doğru. En iyi sonucun korunuyor: '+old.best+' / '+b.total+'.';}
 const better=!old||correct>old.best||(correct===old.best&&dur&&(!old.bestDur||dur<old.bestDur));
 mine[b.id]={best:old?Math.max(old.best,correct):correct,bestAt:better?now:old.bestAt,bestDur:better?dur:old.bestDur,last:correct,lastAt:now,lastDur:dur,n:(old?old.n:0)+1};
 all[pid]=mine;lsSet('rk_best',all);
 RK.msg={sess:s.id,board:b.id,head,text,cloud:''};
 const p=rkProf(pid);
 if(p.status==='lost'){RK.msg.cloud='Bu profilin sıralama kaydına bu telefondan ulaşılamıyor. Rekorun telefonda kayıtlı.';return;}
 if(p.status!=='in'){RK.msg.cloud='Sıralamada görünmüyorsun. İstersen Rekorlarım ekranından listeye dönebilirsin.';return;}
 const q=rkQueue(),name=rkName(st.prof);
 ['genel','hafta'].forEach(period=>q.push({qid:rkRandomId(),pid,board:b.id,period,name,correct,gen:p.gen,at:Date.now(),sess:s.id}));
 lsSet('rk_queue',q);
 RK.msg.cloud=rkOnline()?'Sıralama güncelleniyor…':'Sıran internete bağlanınca görünecek.';
 if(!p.synced)RK.msg.note='Sıralamada yalnız adın görünür. İstemezsen Rekorlarım ekranından listeden çıkabilirsin.';
 rkFlush(s.id);
}
/* Sıradaki sonuçları gönderir. Listeden çıkıldıktan sonra kalan ya da eski nesilden gelen sonuçlar atılır. */
async function rkFlush(sessId){
 if(RK.busy||!rkOnline()||!rkQueue().length)return;const be=rkBackend();if(!be)return;RK.busy=true;
 let outcome=null;
 try{
  const checked={};
  while(rkQueue().length){
   const item=rkQueue()[0],drop=()=>lsSet('rk_queue',rkQueue().filter(x=>x!==null&&(item.qid?x.qid!==item.qid:JSON.stringify(x)!==JSON.stringify(item)))),p=rkProf(item.pid);
   if(p.status!=='in'||item.gen!==p.gen){drop();continue;}
   if(!checked[item.pid]){let sp;try{sp=await be.ensureProfile(item.pid);}catch(e){if(!/permission/i.test(rkErrCode(e)))throw e;rkProfSet(item.pid,{status:'lost'});lsSet('rk_queue',rkQueue().filter(x=>x.pid!==item.pid));if(item.sess===sessId){outcome=outcome||{};outcome.genel={failed:true};}continue;}rkProfSet(item.pid,{status:sp.status,gen:sp.gen,synced:true});checked[item.pid]=sp;}
   const sp=checked[item.pid];if(sp.status!=='in'||sp.gen!==item.gen){drop();continue;}
   if(item.board==='haftalik'&&item.week!==rkWeekNo()){drop();continue;}
   const row={name:rkName(item.name),correct:item.correct,term:RK_TERM,version:RK_VERSION,gen:item.gen,...(item.meta||{}),rank:typeof rutbeNumber==='function'?rutbeNumber(item.pid):1};
   let res=null,table=null;
   const tries=item.period==='genel'?[rkTable(item.board,'genel')]:item.board==='haftalik'?[rkTable(item.board,'hafta',item.week)]:[0,1,-1].map(d=>rkTable(item.board,'hafta',rkWeekNo()+d));
   /* Kural henüz yeni alanları tanımıyorsa sırayla süresiz/rütbesiz eski biçime inilir (uygulama ve kural sırası önemli değildir). */
   const variants=[row],noRank={...row};delete noRank.rank;variants.push(noRank);if('dur' in row){const noDur={...row};delete noDur.dur;const noBoth={...noDur};delete noBoth.rank;variants.push(noDur,noBoth);}
   for(const t of tries){try{rkCleanAdd(item.pid,t);let last=null;for(const v of variants){try{res=await be.submit(t,item.pid,v);last=null;break;}catch(er){if(!/permission/i.test(rkErrCode(er)))throw er;last=er;}}if(last)throw last;table=t;break;}catch(e){if(!/permission/i.test(rkErrCode(e)))throw e;}}
   if(!res){if(RK.msg&&RK.msg.sess===sessId)RK.msg.cloud='Sonucun kaydediliyor.';break;}
   drop();
   if(item.sess===sessId&&!res){outcome=outcome||{};outcome[item.period]={failed:true};}
   if(item.sess===sessId&&res)outcome=outcome||{};
   if(item.sess===sessId&&res&&!res.stale)outcome[item.period]={table,kept:!!res.kept};
  }
  if(outcome&&RK.msg&&RK.msg.sess===sessId){
   const pid=rkPid(st.prof);const parts=[];
   for(const period of ['hafta','genel']){const o=outcome[period];if(!o)continue;if(o.failed){parts.push(period==='hafta'?'Bu haftaki sıralamaya yazılamadı':'Genel sıralamaya yazılamadı');continue;}const rows=await be.list(o.table);const r=rkRank(rows,pid);if(r)parts.push((period==='hafta'?'Bu haftaki sıran: ':'Genel sıran: ')+r.rank+(r.tie>1?' ('+r.tie+' kişiyle aynı sırada)':''));}
   const kept=outcome.genel&&outcome.genel.kept;RK.msg.cloud=parts.length?parts.join(' · ')+(kept?' · En iyi sonucun korunuyor.':'')+(Object.values(outcome).some(o=>o&&o.failed)?'. Sonucun bu telefonda kayıtlı.':''):'Bu sonuç sıralamaya gönderilmedi.';
  }
  if(RK.msg&&RK.msg.sess===sessId&&rkQueue().some(x=>x.sess===sessId))RK.msg.cloud+=' · Sonucun kaydediliyor.';
 }catch(e){if(RK.msg&&RK.msg.sess===sessId)RK.msg.cloud='Sıralamaya şu anda ulaşılamadı. Sonucun telefonda kayıtlı; internet olduğunda yeniden gönderilir.';}
 finally{RK.busy=false;if(RK.again){RK.again=false;setTimeout(rkMaintenance,0);}}
 if(RK.msg&&RK.msg.sess===sessId&&['board','quiz','summary','spicereview'].includes(st.screen))render();
}
/* Sıra: kendisinden daha çok doğru yapan kişi sayısı + 1. Eşitler aynı sırayı paylaşır; ekranda alfabetik dizilir. */
/* Eşit doğruda (yalnız haftalık satırlarda bulunan) daha kısa süre öne geçer; süresi olmayan satır altta sayılır. */
function rkDurV(r){return Number.isInteger(r.dur)&&r.dur>0?r.dur:Infinity;}
function rkBetter(a,b){return a.correct>b.correct||(a.correct===b.correct&&rkDurV(a)<rkDurV(b));}
function rkSame(a,b){return a.correct===b.correct&&rkDurV(a)===rkDurV(b);}
/* Er Meydanı süresi salise (1/100 sn) olarak tutulur: 48,07 sn · 4 dk 05,32 sn */
function rkSaliseYaz(cs){cs=Math.max(0,Math.round(cs));const m=Math.floor(cs/6000),sn=Math.floor(cs%6000/100),sl=cs%100,t=String(sn).padStart(m?2:1,'0')+','+String(sl).padStart(2,'0')+' sn';return m?m+' dk '+t:t;}
function rkFmtDur(s,board){if(board==='ar-puan')return rkSaliseYaz(s);const m=Math.floor(s/60);return String(m).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
function rkSorted(rows){return rows.slice().sort((a,b)=>b.correct-a.correct||(rkDurV(a)===rkDurV(b)?0:rkDurV(a)<rkDurV(b)?-1:1)||String(a.name).localeCompare(String(b.name),'tr'));}
function rkRank(rows,pid){const me=rows.find(r=>r.pid===pid);if(!me)return null;return {rank:rows.filter(r=>rkBetter(r,me)).length+1,tie:rows.filter(r=>rkSame(r,me)).length,row:me};}

/* ---------- Listeden çık / listeye dön / profil silme ---------- */
async function rkCleanup(pid){const be=rkBackend();for(const t of (rkClean()[pid]||[]).slice()){try{await be.removeRow(t,pid);rkCleanDel(pid,t);}catch(e){if(/not.?found/i.test(rkErrCode(e)))rkCleanDel(pid,t);else throw e;}}return !(rkClean()[pid]||[]).length;}
async function rkLeave(){
 const pid=rkPid(st.prof,true);if(!rkOnline()){RK.view.notice='Listeden çıkmak için internete bağlan.';render();return;}
 RK.view.notice='Bu cihazdan yeni sonuç gönderilmeyecek. Kayıtların kaldırılıyor…';render();
 try{const be=rkBackend();lsSet('rk_queue',rkQueue().filter(x=>x.pid!==pid));const sp=await be.ensureProfile(pid);rkProfSet(pid,{status:sp.status,gen:sp.gen,synced:true});
  if(sp.status==='in'){const n=await be.setStatus(pid,'out');rkProfSet(pid,{status:n.status,gen:n.gen});}
  const done=await rkCleanup(pid);RK.view.notice=done?'Kayıtların listeden kaldırıldı.':'Bazı kayıtlar kaldırılamadı. İnternet olduğunda yeniden denenecek.';
 }catch(e){RK.view.notice='Şu anda tamamlanamadı. İnternet bağlantını kontrol edip yeniden dene.';}
 render();
}
async function rkJoin(){
 const pid=rkPid(st.prof,true);if(!rkOnline()){RK.view.notice='Listeye dönmek için internete bağlan.';render();return;}
 try{const be=rkBackend();if(!(await rkCleanup(pid))){RK.view.notice='Eski kayıtlar henüz kaldırılamadı. Biraz sonra yeniden dene.';render();return;}
  const sp=await be.ensureProfile(pid);if(sp.status==='out'){const n=await be.setStatus(pid,'in');rkProfSet(pid,{status:n.status,gen:n.gen,synced:true});}else rkProfSet(pid,{status:sp.status,gen:sp.gen,synced:true});
  RK.view.notice='Listeye döndün. Bundan sonraki Uyguluyorum sonuçların sıralamaya yazılır.';
 }catch(e){RK.view.notice='Şu anda tamamlanamadı. İnternet bağlantını kontrol edip yeniden dene.';}
 render();
}
function rkForgetProfile(name){
 const ids=rkIds(),pid=ids[name];if(!pid)return;delete ids[name];lsSet('rk_ids',ids);
 const b=rkBestAll();delete b[pid];lsSet('rk_best',b);const pk=rkPekAll();delete pk[pid];lsSet('rk_pek',pk);
 for(const key of ['yanlislarim','dost_secim','dost_gorev']){const all=ls(key,{});if(Object.hasOwn(all,pid)){delete all[pid];lsSet(key,all);}}
 if(typeof DOST_CHARACTERS!=='undefined')Object.keys(DOST_CHARACTERS).forEach(id=>localStorage.removeItem(PRE+'dost_gorunum_'+id+'_'+pid));
 lsSet('rk_queue',rkQueue().filter(x=>x.pid!==pid));rkProfSet(pid,{pendingDelete:true});rkMaintenance();
}
/* Açılışta ve bağlantı gelince: yarım kalan silme/temizlik işlerini bitirir, bekleyen sonuçları gönderir. */
async function rkMaintenance(){
 if(!rkOnline())return;if(RK.busy||RK.maint){RK.again=true;return;}RK.maint=true;try{await rkMaintenanceRun();}finally{RK.maint=false;}if(RK.again){RK.again=false;setTimeout(rkMaintenance,0);}
}
async function rkMaintenanceRun(){const all=rkProfAll(),clean=rkClean(),be=rkBackend();if(!be)return;
 for(const pid of Object.keys(all)){
  const p=all[pid];
  try{
   if(p.pendingDelete&&p.status!=='deleted'){
    if(!p.synced&&!(clean[pid]||[]).length){const a=rkProfAll();delete a[pid];lsSet('rk_prof',a);continue;}
    const n=await be.setStatus(pid,'deleted');rkProfSet(pid,{status:n.status,gen:n.gen});
   }
   if(['out','deleted'].includes(rkProf(pid).status)&&(clean[pid]||[]).length)await rkCleanup(pid);
   if(rkProf(pid).status==='deleted'&&!(rkClean()[pid]||[]).length){const a=rkProfAll();delete a[pid];lsSet('rk_prof',a);}
  }catch(e){if(rkErrCode(e)==='NO_PROFILE'){const a=rkProfAll();delete a[pid];lsSet('rk_prof',a);}}
 }
 rkFlush(null);
}

/* ---------- Kapışma ve Er Meydanı sıralaması ----------
   Telefonda toplam kazanılan sayı (genel ve haftalık) tutulur; her artışta sıralamaya yalnız büyüyen sayı yazılır. */
function rkWinAdd(board,n){
 n=n|0;if(n<=0||st.guest||!st.prof||!rkBoard(board))return;
 const pid=rkPid(st.prof,true),p=rkProf(pid);
 const all=ls('rk_win',{}),mine=all[pid]=all[pid]||{},b=mine[board]=mine[board]||{g:0,w:{}},wk='w'+rkWeekNo();
 b.g=Math.min(999,(b.g|0)+n);b.w[wk]=Math.min(999,(b.w[wk]|0)+n);
 Object.keys(b.w).forEach(k=>{if(k!==wk&&Number(k.slice(1))<rkWeekNo()-3)delete b.w[k];});
 lsSet('rk_win',all);
 if(p.status!=='in')return;
 const q=rkQueue(),name=rkName(st.prof);
 [['genel',b.g],['hafta',b.w[wk]]].forEach(([period,correct])=>q.push({qid:rkRandomId(),pid,board,period,name,correct,gen:p.gen,at:Date.now(),sess:null}));
 lsSet('rk_queue',q);rkFlush(0);
}
/* ---------- Pekiştiriyorum verisi ---------- */
/* Oturumdaki i. soru, i. yanıt satırıdır (sorular sırayla tek tek yanıtlanır); metin eşleşmezse metinle aranır. */
function rkMcqRow(i,q){const s=st.sess,r=s.qs[i];if(r&&(r.qid?r.qid===q.id:r.q===q.prompt))return r;return s.qs.find(x=>x.qid===q.id)||null;}
function rkToday(){return new Date().toLocaleDateString('sv-SE');}
/* Bağımsız doğru, son yanlıştan ya da son sayılan doğrudan farklı bir günde yapılırsa sayılır. Aynı günkü doğru kaydedilir ama listeden çıkarmaz. */
function rkPekMark(map,key,info,correct,wrongName){
 const it=map[key],today=rkToday();
 if(correct){if(!it)return;it.at=Date.now();if(it.day===today)return;it.streak=(it.streak||0)+1;it.day=today;if(it.streak>=2)delete map[key];return;}
 const n=it||{...info,streak:0,wrong:[]};n.streak=0;n.at=Date.now();n.day=today;if(wrongName&&!n.wrong.includes(wrongName))n.wrong.push(wrongName);map[key]=n;
}
function rkPekFromAssessment(pid){
 const map=rkPek(pid),s=st.sess,wrong=[],known=[];
 const mk=(key,info,correct,wn)=>{rkPekMark(map,key,info,correct,wn);(correct?known:wrong).push(key);};
 let kind=null,arg=null;
 if(st.op==='match'&&st.board){kind='m';arg=st.contentSet;st.board.items.forEach(it=>{const nm=st.board.pair[it.id];mk('m|'+st.subject+'|'+st.contentSet+'|'+it.id,{kind:'m',subject:st.subject,set:st.contentSet,id:it.id},nm===it.answer,nm&&nm!==it.answer?nm:null);});}
 else if(st.op==='mcq'){kind='q';(st.contentItems||[]).forEach((q,i)=>{const row=rkMcqRow(i,q);if(!row||row.r===null)return;mk('q|'+st.subject+'|'+q.id,{kind:'q',subject:st.subject,id:q.id},row.r===1,null);});}
 else if(st.op==='kur'){kind='k';arg=st.lvl;s.qs.forEach(row=>{if(!row.prompt)return;mk('k|'+st.lvl+'|'+row.prompt,{kind:'k',subject:'kuver',lvl:st.lvl,id:row.prompt},row.r===1,null);});}
 rkPekSave(pid,map);
 /* Oyun sonunda "Birlikte tekrar edelim" düğmesi için yalnız bu çalışmanın yanlışları (doğru yapılan madde tekrar turuna girmez). */
 /* Kuver'de düğme yok: tur kalan parçaların hepsini de sorar. Kuver yanlışları Pekiştiriyorum menüsünden çalışılır. */
 RK.tk=kind&&kind!=='k'&&wrong.length?{sess:s.id,prof:st.prof,kind,arg,subject:st.subject,keys:wrong,known:[],n:Math.min(wrong.length,4),more:wrong.length>4}:null;
}
/* Anahtardan (m|konu|takım|id, q|konu|id) bildiği maddenin bilgisini çıkarır. */
function rkPekKnown(key){const a=String(key).split('|');if(a[0]==='m')return {kind:'m',subject:a[1],set:Number(a[2]),id:a.slice(3).join('|')};if(a[0]==='q')return {kind:'q',subject:a[1],id:a.slice(2).join('|')};return null;}
function rkTekrarHTML(){
 const t=RK.tk;if(!t||!st.sess||t.sess!==st.sess.id||st.guest||t.prof!==st.prof)return '';
 const n=t.n;
 return '<section class="card rk-tekrar" role="status"><strong>Birlikte tekrar edelim</strong><p>'+n+' maddeyle yeniden çalışalım. Bu tur sıralamaya yazılmaz.'+(t.more?' Kalanlar Pekiştiriyorum listende bekler.':'')+'</p><button class="btn pri" onclick="rkTekrarBasla()">Birlikte tekrar edelim ('+n+')</button>'+(t.kind==='m'?'<button class="btn" onclick="rkCalisBasla()">📖 Bu '+rkCalisAd(t.subject,t.keys.length)+' çalış</button>':'')+'</section>';
}
/* "Bu 3 aracı çalış": karıştırılan maddeler önce kartlarla (fotoğraf, ad, ne işe yaradığı) çalışılır, sonra yalnız onlarla denenir.
   Bir seferde 3 madde: bu öğrenciler için bir kerede çalışılabilecek kadar; kalanlar "sıradaki 3" ile gelir. */
const RK_ADLAR={'mutfak-araclari':'aracı','baharat':'ürünü','bulasik-makinesi-temizligi':'nesneyi'};
function rkCalisAd(subject,total,pos){const n=Math.min(3,total-(pos||0));return (n>1?n+' ':'')+(RK_ADLAR[subject]||'maddeyi');}
function rkCalisItems(){const c=RK.cal;if(!c)return [];const arr=(CONTENT[c.subject]&&CONTENT[c.subject].matches)||[];return c.keys.slice(c.pos,c.pos+3).map(k=>{const i=rkPekKnown(k);return i&&arr.find(x=>x.set===i.set&&x.id===i.id);}).filter(Boolean);}
function rkCalisBasla(){const t=RK.tk;if(!t||st.guest||t.prof!==st.prof||t.kind!=='m')return;RK.cal={subject:t.subject,set:t.arg,keys:t.keys.slice(),pos:0,prof:t.prof};RK.tk=null;st.subject=t.subject;sesSus();go('pekcalis');window.scrollTo(0,0);}
function rkCalisSonraki(){if(!RK.cal)return;RK.cal.pos+=3;sesSus();render();window.scrollTo(0,0);}
function rkCalisDene(){const c=RK.cal;if(!c||c.prof!==st.prof)return;const keys=c.keys.slice(c.pos,c.pos+3);sesSus();st.subject=c.subject;RK.cal=null;rkPekStart('m',c.set,{keys,known:[]});}
function rkCalisHTML(){
 const c=RK.cal,its=rkCalisItems();if(!c||!its.length)return topBar(subjectName())+'<div class="wrap"><p class="card">Çalışılacak madde yok.</p></div>';
 const more=c.keys.length-(c.pos+3);
 let h=topBar(subjectName())+'<div class="wrap rk-cal"><h1 id="rkCalBaslik" tabindex="-1">Bu '+rkCalisAd(c.subject,c.keys.length,c.pos)+' çalış</h1><p class="sub">Her kartta fotoğrafı, adı ve ne işe yaradığı var. Oku, sonra dene. Bu bölüm puan vermez.</p>';
 its.forEach(it=>{h+='<article class="card rk-cal-kart"><img src="'+esc(it.image)+'" alt="'+esc(it.imageAlt||it.answer)+'"><h2>'+esc(it.answer)+'</h2><p>'+esc(it.explanation||'')+'</p>'+(typeof sesDugme==='function'?sesDugme(it.answer+'. '+(it.explanation||''),it.answer+' kartını dinle'):'')+'</article>';});
 h+='<button class="btn pri" onclick="rkCalisDene()">Şimdi dene ('+its.length+')</button>';
 if(more>0)h+='<button class="btn" onclick="rkCalisSonraki()">Sıradaki '+rkCalisAd(c.subject,c.keys.length,c.pos+3)+' çalış</button>';
 return h+'</div>';
}
function rkTekrarBasla(){const t=RK.tk;if(!t||st.guest||t.prof!==st.prof){RK.tk=null;return;}RK.tk=null;st.subject=t.subject;rkPekStart(t.kind,t.arg,{keys:t.keys,known:t.known});}
function rkPekItems(subject){if(st.guest||!st.prof)return [];const pid=rkPid(st.prof);if(!pid)return [];return Object.entries(rkPek(pid)).filter(([k,v])=>v.subject===subject).map(([k,v])=>({key:k,...v}));}
function rkPekGroups(subject){
 const items=rkPekItems(subject),out=[];
 const q=items.filter(x=>x.kind==='q');if(q.length)out.push({kind:'q',label:'Çoktan seçmeli sorular',n:q.length,arg:0});
 /* Öğrenme yolu olan konularda eşleştirme pekiştirmesi yoktur: eşleştirme 6'lı yolun içinde ve Tekrar Çalışması'nda yapılır. */
 const yolda=typeof yolKonuVar==='function'&&yolKonuVar(subject);
 if(!yolda)[...new Set(items.filter(x=>x.kind==='m').map(x=>x.set))].sort((a,b)=>a-b).forEach(n=>out.push({kind:'m',label:n+'. takım · Eşleştirme',n:items.filter(x=>x.kind==='m'&&x.set===n).length,arg:n}));
 [1,3].forEach(l=>{const c=items.filter(x=>x.kind==='k'&&x.lvl===l).length;if(c)out.push({kind:'k',label:(l===3?'Tabldot':'Basit')+' Kuver',n:c,arg:l});});
 return out;
}
/* Tur bitince sayaç güncellenir. Yalnız ilk ve yardımsız yanıt (r===1) bağımsız doğru sayılır. */
function rkPekProcess(){
 const s=st.sess;s.rkPekDone=true;if(st.guest||!st.prof)return;const pid=rkPid(st.prof,true),map=rkPek(pid),r=st.pekRound||{};
 if(r.kind==='q')(st.contentItems||[]).forEach((q,i)=>{const row=rkMcqRow(i,q);if(row)rkPekMark(map,'q|'+st.subject+'|'+q.id,{kind:'q',subject:st.subject,id:q.id},row.r===1,null);});
 if(r.kind==='m'&&st.board)st.board.items.forEach(it=>{const res=st.board.res[it.id];if(res===undefined)return;const at=(st.board.attempts[it.id]||[]).find(x=>!x.correct);rkPekMark(map,'m|'+st.subject+'|'+st.contentSet+'|'+it.id,{kind:'m',subject:st.subject,set:st.contentSet,id:it.id},res===1,at?at.answer:null);});
 if(r.kind==='k')s.qs.forEach(row=>{if(row.prompt&&(r.targets||[]).includes(row.prompt))rkPekMark(map,'k|'+st.lvl+'|'+row.prompt,{kind:'k',subject:'kuver',lvl:st.lvl,id:row.prompt},row.r===1,null);});
 rkPekSave(pid,map);
 const left=rkPekItems(st.subject).length;
 RK.msg={sess:s.id,head:'Bu turu tamamladın.',text:left?'Tekrar edilecek '+left+' madde kaldı. Bir madde, iki ayrı günde ilk denemede doğru yapılınca listeden çıkar.':'Bu konuda tekrar edilecek madde kalmadı.',cloud:'',pek:true};
}
function rkPekStart(kind,arg,opts){
 opts=opts||{};const LIM=opts.keys?4:null;
 let items=rkPekItems(st.subject).sort((a,b)=>(a.streak||0)-(b.streak||0)||(a.at||0)-(b.at||0));
 if(opts.keys)items=items.filter(x=>opts.keys.includes(x.key));
 const knownItem=opts.known&&opts.known.length?rkPekKnown(opts.known[0]):null;
 st.brk=0;st.kDone=false;st.done=false;st.inBreak=false;RK.msg=null;
 if(kind==='q'){
  st.op='mcq';const qs=getData().questions,pick=items.filter(x=>x.kind==='q').slice(0,LIM||8).map(x=>qs.find(q=>q.id===x.id)).filter(Boolean);
  if(!pick.length){go('pekmenu');return;}
  const kq=knownItem&&knownItem.kind==='q'?qs.find(q=>q.id===knownItem.id):null;
  st.practice='pek';st.mcqGroup='Pekiştiriyorum';st.pekRound={kind:'q'};st.contentItems=mcqUnique(shuffle(pick).concat(kq?[kq]:[])).map(mcqShuffled);st.contentIndex=0;st.contentSet=null;
  st.sess={id:Date.now(),p:st.prof,t:new Date().toISOString(),op:'mcq',subject:st.subject,practice:'pek',total:st.contentItems.length,group:'Pekiştiriyorum',s:0,ok:0,fix:0,bad:0,br:0,qs:[]};
  st.savedMsg='';contentNext();st.screen='quiz';render();window.scrollTo(0,0);return;
 }
 if(kind==='m'){
  st.op='match';st.contentSet=arg;const full=contentArr().filter(x=>x.set===arg),targets=items.filter(x=>x.kind==='m'&&x.set===arg).slice(0,4);
  const its=targets.map(t=>full.find(x=>x.id===t.id)).filter(Boolean);if(!its.length){go('pekmenu');return;}
  if(knownItem&&knownItem.kind==='m'&&knownItem.set===arg){const kx=full.find(x=>x.id===knownItem.id);if(kx&&!its.includes(kx))its.push(kx);}
  /* Ad havuzu: hedeflerin doğru adları + öğrencinin gerçekten seçtiği yanlış adlar + gerekirse aynı takımın öğretilmiş adları. Dolgu çeldirici yok. */
  const names=[];const add=n=>{if(n&&!names.includes(n))names.push(n);};its.forEach(x=>add(x.answer));targets.forEach(t=>(t.wrong||[]).forEach(add));
  shuffle(full.filter(x=>!its.includes(x)).map(x=>x.answer)).forEach(n=>{if(names.length<its.length+2)add(n);});
  st.practice='learn';st.pekRound={kind:'m',set:arg};
  st.board={items:shuffle(its),names:shuffle(names),extra:names.length-its.length,pair:{},sel:null,selName:null,tries:{},res:{},attempts:{},responseTime:{},checked:false,size:its.length,variant:true};
  st.lastRes={cls:'',head:'Pekiştiriyorum: görselleri adlarıyla eşleştir.',text:'Bir görsele dokun, sonra adını seç. Bazı adların görseli yoktur.',intro:true};
  st.sess={id:Date.now(),p:st.prof,t:new Date().toISOString(),op:'match',subject:st.subject,practice:'pek',set:arg,s:0,ok:0,fix:0,bad:0,br:0,total:its.length,qs:[]};
  st.savedMsg='';if(typeof PHONE!=='undefined'){PHONE.open=false;PHONE.expanded=false;}tStart();st.screen='board';render();window.scrollTo(0,0);return;
 }
 if(kind==='k'){
  const targets=items.filter(x=>x.kind==='k'&&x.lvl===arg).slice(0,LIM||99).map(x=>x.id);if(!targets.length){go('pekmenu');return;}
  st.op='kur';st.lvl=arg;st.practice='learn';st.pekRound={kind:'k',targets};RK.startingPek=true;try{startSession();}finally{RK.startingPek=false;}st.sess.practice='pek';
  /* Yanlış yerleştirilen parçalar önce sorulur; ekmek tabağı tereyağı bıçağından önce gelir. */
  let first=st.order.filter(k=>targets.includes(k)),rest=st.order.filter(k=>!targets.includes(k));
  const fix=a=>{const i=a.indexOf('ekmek_tabagi'),j=a.indexOf('tereyagi_bicagi');if(i>-1&&j>-1&&j<i){a[i]='tereyagi_bicagi';a[j]='ekmek_tabagi';}return a;};
  if(first.includes('tereyagi_bicagi')&&!first.includes('ekmek_tabagi')&&rest.includes('ekmek_tabagi')){rest=rest.filter(k=>k!=='ekmek_tabagi');first.unshift('ekmek_tabagi');}
  st.order=fix(first).concat(rest);newQ(true);st.lastRes={cls:'',head:'Pekiştiriyorum: önce yanlış yerleştirdiğin parçalar gelecek.',text:ITEMS.kuver_tabagi.kural};render();return;
 }
}
function rkPekMenuHTML(){
 const gs=rkPekGroups(st.subject);let h=topBar(subjectName())+'<div class="wrap"><h1>Pekiştiriyorum</h1>';
 if(!gs.length)return h+'<p class="card">Bu konuda tekrar edilecek madde yok. Uyguluyorum\'da yanlış yaptığın maddeler burada toplanır.</p></div>';
 h+='<p class="sub">Uyguluyorum\'da yanlış yaptığın maddeler burada listelenir. Bir madde, iki ayrı günde ilk denemede doğru yapılınca listeden çıkar. Bu tur sıralamaya yazılmaz.</p><div class="list">';
 gs.forEach(g=>h+=menuButton(g.label,g.n+' madde',"rkPekStart('"+g.kind+"',"+g.arg+")"));
 return h+'</div></div>';
}

/* ---------- Rekorlarım ve sıralama ekranları ---------- */
function rkTabs(active){return '<div class="rk-tabs" role="tablist">'+(st.guest?'':'<button role="tab" aria-selected="'+(active==='rekor')+'" class="btn'+(active==='rekor'?' pri':'')+'" onclick="go(\'rekor\')">Rekorlarım</button>')+'<button role="tab" aria-selected="'+(active==='siralama')+'" class="btn'+(active==='siralama'?' pri':'')+'" onclick="rkOpenBoard()">Sıralama</button></div>';}
function rkFmtDate(iso){return iso?fmtDate(iso):'';}
function rkParticipationHTML(){
 const pid=rkPid(st.prof);const p=pid?rkProf(pid):{status:'in'};const pending=pid&&(rkClean()[pid]||[]).length;
 let h='<section class="card rk-part"><h2>Sıralamada görünme</h2>';
 if(p.status==='lost')return h+'<p>Bu profilin sıralama kaydına bu telefondan ulaşılamıyor. Telefonun site verileri silinmiş olabilir. Öğretmenine haber ver; istersen yeni bir profil açabilirsin.</p></section>';
 if(p.status==='in')h+='<p>Sıralamada yalnız adın (<b>'+esc(rkName(st.prof))+'</b>) görünür. Uyguluyorum sonuçlarınla listeye girersin.</p><button class="btn" onclick="rkLeave()">Listeden çık</button>';
 else h+='<p>Şu anda sıralamada görünmüyorsun. Rekorların yalnız bu telefonda tutuluyor.</p><button class="btn" onclick="rkJoin()"'+(pending&&!rkOnline()?' disabled':'')+'>Listeye dön</button>';
 if(RK.view.notice)h+='<p class="note" role="status">'+esc(RK.view.notice)+'</p>';
 return h+'</section>';
}
function rkRecordsHTML(){
 let h=topBar('Rekorlarım')+'<div class="wrap">'+rkTabs('rekor');
 const pid=rkPid(st.prof),mine=pid?(rkBestAll()[pid]||{}):{};
 h+=rkParticipationHTML();
 const ids=Object.keys(mine);
 if(!ids.length)return h+'<p class="card">Henüz rekor yok. Uyguluyorum bölümünü bitirince sonuçların burada görünür.</p></div>';
 Object.keys(RK_SUBJECT_NAMES).forEach(sub=>{
  const bs=RK_BOARDS.filter(b=>b.subject===sub&&mine[b.id]);if(!bs.length)return;
  h+='<h2 class="grp-h">'+esc(RK_SUBJECT_NAMES[sub])+'</h2><div class="rk-list">';
  bs.forEach(b=>{const r=mine[b.id];h+='<div class="rk-rec"><div><b>'+esc(b.label)+'</b><span>En iyi sonucun: <b>'+r.best+' / '+b.total+'</b>'+(r.bestDur?' · '+fmtDur(r.bestDur):'')+'</span><span class="note">Son deneme: '+r.last+' / '+b.total+' · '+rkFmtDate(r.lastAt)+'</span></div>'+(b.gizli?'':'<button class="btn sm" onclick="rkOpenBoard(\''+b.id+'\')">Sıralama</button>')+'</div>';});
  h+='</div>';
 });
 return h+'<p class="note">Süre yalnız bu telefonda tutulur, sıralamayı etkilemez.</p></div>';
}
function rkOpenBoard(id){
 const pid=st.prof?rkPid(st.prof):null,mine=pid?(rkBestAll()[pid]||{}):{};
 const last=Object.entries(mine).sort((a,b)=>String(b[1].lastAt).localeCompare(String(a[1].lastAt)))[0];
 RK.view.week=null;if(id&&rkDynamicBoard(id)&&!RK_BOARDS.some(b=>b.id===id))RK_BOARDS.push(rkDynamicBoard(id));RK.view.board=id||RK.view.board||(last&&last[0]&&!(rkBoard(last[0])||{}).gizli&&last[0])||'haftalik';RK.view.rows=null;RK.view.state='idle';RK.view.err='';RK.view.crown=true;go('siralama');rkLoadRows();
}
function rkPickSubject(sub){const b=RK_BOARDS.find(x=>x.subject===sub&&!x.gizli);if(b)rkOpenBoard(b.id);}
function rkPickPeriod(p){RK.view.period=RK.view.board==='haftalik'?'hafta':p;RK.view.rows=null;render();rkLoadRows();}
async function rkLoadRows(){
 const v=RK.view,key=v.board+'|'+v.period+'|'+(v.week||'');if(!rkOnline()){v.state='offline';render();return;}
 v.state='loading';render();
 try{const be=rkBackend();if(!be)throw Error('NO_CONFIG');const rows=await be.list(rkTable(v.board,v.period==='genel'?'genel':'hafta',v.week));if(v.board+'|'+v.period+'|'+(v.week||'')!==key)return;v.rows=rows;v.state='ready';}
 catch(e){if(v.board+'|'+v.period+'|'+(v.week||'')!==key)return;v.state='error';v.err=rkErrCode(e)==='NO_CONFIG'?'Sıralama bağlantısı ayarlanmadı.':'Sıralamaya şu anda ulaşılamadı.';}
 if(st.screen==='siralama'){render();if(v.crown&&v.state==='ready'&&v.period==='hafta'&&v.board!=='haftalik'){v.crown=false;rkCrownShow(v.rows);}}
}
function rkBoardHTML(){
 const v=RK.view,b=rkBoard(v.board)||RK_BOARDS.find(x=>!x.gizli),pid=st.prof&&!st.guest?rkPid(st.prof):null;
 let h=topBar('Sıralama')+'<div class="wrap">'+rkTabs('siralama');if(typeof kaptanKartHTML==='function')h+=kaptanKartHTML();
 h+='<div class="card rk-pick"><label>Konu <select onchange="rkPickSubject(this.value)">'+Object.keys(RK_SUBJECT_NAMES).filter(s=>RK_BOARDS.some(x=>x.subject===s&&!x.gizli)).map(s=>'<option value="'+s+'"'+(s===b.subject?' selected':'')+'>'+esc(RK_SUBJECT_NAMES[s])+'</option>').join('')+'</select></label>';
 h+='<label>Çalışma <select onchange="rkOpenBoard(this.value)">'+RK_BOARDS.filter(x=>x.subject===b.subject&&!x.gizli).map(x=>'<option value="'+x.id+'"'+(x.id===b.id?' selected':'')+'>'+esc(x.label)+'</option>').join('')+'</select></label>';
 h+='<div class="rk-period" role="group" aria-label="Dönem"><button class="btn sm'+(v.period==='hafta'?' pri':'')+'" aria-pressed="'+(v.period==='hafta')+'" onclick="rkPickPeriod(\'hafta\')">Bu hafta</button><button class="btn sm'+(v.period==='genel'?' pri':'')+'" aria-pressed="'+(v.period==='genel')+'" onclick="rkPickPeriod(\'genel\')">Genel</button></div></div>';
 h+='<h2 class="rk-title">'+esc(RK_SUBJECT_NAMES[b.subject]+' · '+b.label)+'</h2><p class="note">'+(v.period==='hafta'?'Hafta: '+rkWeekLabel(v.week||rkWeekNo())+'. Liste her pazartesi yeniden başlar.<br>İnternetsiz tamamladığın sonuç, gönderildiği haftaya yazılır.':'Bu eğitim yılının en iyi sonuçları.')+'<br>'+(b.kind==='win'?'Kazanılan sayı gösterilir.':'Her öğrencinin en iyi doğru sayısı gösterilir.')+'</p>';
 if(b.kind==='weekly')h+='<p class="card">'+(v.week&&v.week<rkWeekNo()?'Geçen haftanın birincisi':'Bu haftanın lideri')+' · Dört konu · 100 soru · 12. yanlışta biter.</p>';
 if(v.state==='offline')return h+'<p class="card" role="status">Sıralamayı görmek için internete bağlan.</p></div>';
 if(v.state==='loading'||v.state==='idle')return h+'<p class="card" role="status">Sıralama yükleniyor…</p></div>';
 if(v.state==='error')return h+'<p class="card" role="alert">'+esc(v.err)+'</p><button class="btn" onclick="rkLoadRows()">Yeniden dene</button></div>';
 const rows=rkSorted(v.rows||[]);if(!rows.length)return h+'<p class="card">Bu listede henüz sonuç yok. '+(b.kind==='win'?'İlk kazanan sen olabilirsin.':'Uyguluyorum bölümünü bitiren ilk kişi sen olabilirsin.')+'</p></div>';
 h+='<h3>İlk 10</h3>'+rkRowsHTML(rows,b.id,v.period,10)+'</div>';
 return h;
}
/* Sıralamaya her girişte haftanın birincisinin adı ortada taç animasyonuyla gösterilir. */
function rkCrownNames(rows){
 const r=rkSorted(rows||[]);if(!r.length)return [];const top=r[0];return r.filter(x=>rkSame(x,top)).map(x=>x.name);
}
function rkCrownShow(rows){
 const names=rkCrownNames(rows);if(!names.length)return;
 const old=document.getElementById('rkCrown');if(old)old.remove();
 const shown=names.slice(0,3).map(esc).join(', ')+(names.length>3?' +'+(names.length-3):'');
 const d=document.createElement('div');d.id='rkCrown';d.className='rk-crownbox';d.setAttribute('role','status');d.setAttribute('aria-live','polite');
 d.innerHTML='<div class="rk-crowncard"><div class="rk-bigcrown" aria-hidden="true">👑</div><p class="rk-cl">Haftanın Mutfak Kaptanı</p><p class="rk-cn">'+shown+'</p><p class="rk-ch">Kapatmak için dokun</p></div>';
 const kapat=()=>{clearTimeout(d._t);d.remove();};d.onclick=kapat;d._t=setTimeout(kapat,4000);
 document.body.appendChild(d);
}
function rkBannerHTML(){
 const m=RK.msg;if(!m||!st.sess||m.sess!==st.sess.id)return '';
 return '<section class="card rk-banner'+(m.head==='Yeni rekor!'?' rk-new':'')+'" role="status"><strong>'+esc(m.head)+'</strong><p>'+esc(m.text)+'</p>'+(m.cloud?'<p class="note">'+esc(m.cloud)+'</p>':'')+(m.note?'<p class="note">'+esc(m.note)+'</p>':'')+(m.board?'<button class="btn sm" onclick="rkOpenBoard(\''+m.board+'\')">Sıralamayı gör</button>':'')+(m.pek&&rkPekItems(st.subject).length?'<button class="btn sm" onclick="go(\'pekmenu\')">Pekiştiriyorum listesine dön</button>':'')+'</section>';
}
/* 12 görsel / 18 adlık puansız deneme (yoklama) kaldırıldı: öğrenci hiçbir ekranda 12'li eşleştirme ile çalışmaz. */

/* ---------- Ekran ve akış bağlantıları ---------- */
const RK_SAVE=saveProgress;
saveProgress=function(){
 if(st.sess&&(st.sess.unranked||st.sess.practice==='pek')){st.sess.s=0;if(st.lastRes&&st.lastRes.head)st.lastRes.head=st.lastRes.head.replace(/\s*\+\d+ puan\.?/,'');}
 return RK_SAVE.apply(this,arguments);};
const RK_RENDER=render,RK_BACK=back,RK_CAT=catName,RK_STATS=statsHtml,RK_ANSWER=answer,RK_START=startSession,RK_STARTBOARD=startBoard,RK_STARTCONTENT=startContent;
/* Yeni normal oturum başlarken önceki pekiştirme/yoklama işaretleri taşınmaz. */
startSession=function(){if(!RK.startingPek)st.pekRound=null;return RK_START.apply(this,arguments);};
startBoard=function(){st.pekRound=null;return RK_STARTBOARD.apply(this,arguments);};
startContent=function(){st.pekRound=null;return RK_STARTCONTENT.apply(this,arguments);};
catName=function(r){const s=RK_CAT(r);if(r.unranked)return s.replace(' · Uyguluyorum','')+' · Puansız deneme';return r.practice==='pek'?s.replace(' · Öğreniyorum','')+' · Pekiştiriyorum':s;};
statsHtml=function(){if(st.practice==='pek'&&st.op==='mcq'&&st.sess&&st.screen!=='summary')return '<div class="stats"><span class="chip">Yanıtlanan '+st.sess.qs.length+' / '+(st.contentItems||[]).length+'</span></div>';return RK_STATS();};
/* Pekiştiriyorum'da çoktan seçmeli: tek yanıt, hemen geri bildirim ve açıklama. İpucuyla ikinci deneme yok. */
answer=function(v){
 if(!(st.practice==='pek'&&st.op==='mcq'))return RK_ANSWER(v);
 if(st.done||!st.q||st.inBreak||st.modalOpen)return;if(typeof sesSus==='function')sesSus();
 const q=st.q,c=q.choices.find(x=>x.id===v);if(!c)return;const right=v===q.correct,secs=tStop();
 st.done=true;st.res=right?1:0;st.wrong=right?[]:[v];if(right)st.sess.ok++;else st.sess.bad++;
 st.sess.qs.push({qid:q.id,q:q.prompt,a:q.correctText,r:st.res,s:secs,selectedAnswer:c.text||c.id+' seçeneği',firstAnswer:c.text||c.id+' seçeneği',attemptCount:1,hintUsed:false,assessment:false,explanation:q.explanation||'',source:q.source});
 st.lastRes={cls:right?'ok':'fix',head:right?'Doğru.':'Doğru yanıt: '+q.correctText,text:q.explanation||''};saveProgress();render();
};
back=function(){if(st.screen==='rekor'||st.screen==='siralama'){go('home');return;}if(st.screen==='pekmenu'){go('subject');return;}if(st.screen==='pekcalis'){sesSus();RK.cal=null;go('subject');return;}RK_BACK();};
const RK_DELPROF=askDelProfile;
askDelProfile=function(n){
 const pid=rkPid(n),cloud=pid&&(rkProf(pid).synced||(rkClean()[pid]||[]).length||rkQueue().some(x=>x.pid===pid));
 if(cloud&&!rkOnline()){modal('Bu profilin sıralamada kayıtları var. Profili silmek için internete bağlan.',closeModal);const no=document.getElementById('mNo'),yes=document.getElementById('mYes');if(no)no.remove();if(yes){yes.textContent='Tamam';yes.focus();}return;}
 modal('“'+esc(n)+'” hesabı silinsin mi? Puanların, rütben, çalışma geçmişin ve sıralamadaki satırların kaldırılır. Bu işlem geri alınamaz.',function(){
  lsSet('profiles',profiles().filter(x=>x!==n));lsSet('records',records().filter(r=>r.p!==n));rkForgetProfile(n);profilSilindi(n);closeModal();render();
 });
};
render=function(){
 if(st.sess&&!rkRaceActive()&&rkSessionDone()){
  if(st.sess.practice==='check'&&!st.sess.rkDone)rkAfterAssessment();
  else if(st.sess.practice==='pek'&&!st.sess.rkPekDone)rkPekProcess();
 }
 if(st.sess&&st.sess.unranked)st.sess.s=0;
 const app=document.getElementById('app');
 if(st.screen==='rekor'){if(st.guest){st.screen='siralama';}else{app.innerHTML=rkRecordsHTML();return;}}
 if(st.screen==='siralama'){app.innerHTML=rkBoardHTML();return;}
 if(st.screen==='pekmenu'){app.innerHTML=rkPekMenuHTML();return;}
 if(st.screen==='pekcalis'){app.innerHTML=rkCalisHTML();const hb=document.getElementById('rkCalBaslik');if(hb)hb.focus();return;}
 RK_RENDER();
 if(st.screen==='home'){const list=app.querySelector('.wrap .list');if(list)list.insertAdjacentHTML('beforeend',menuButton(st.guest?'Sıralama':'Rekorlarım ve Sıralama',st.guest?'Uyguluyorum sonuçlarının haftalık ve genel listesi.':'Kendi en iyi sonuçların, haftalık ve genel liste.',st.guest?"rkOpenBoard()":"go('rekor')"));}
 /* Öğrenme yolu olan konularda Pekiştiriyorum yalnız çoktan seçmeli sorular için açılır (eşleştirme pekiştirmesi yolun içindedir). */
 if(st.screen==='subject'&&!st.guest&&!rkRaceActive()&&(!(typeof yolKonuVar==='function'&&yolKonuVar(st.subject))||rkPekGroups(st.subject).length)){const list=app.querySelector('.wrap .list'),n=rkPekGroups(st.subject).reduce((t,g)=>t+g.n,0);if(list){list.insertAdjacentHTML('beforeend',menuButton('Pekiştiriyorum'+(n?' ('+n+')':''),n?'Uyguluyorum\'da yanlış yaptıklarını tekrar et.':'Uyguluyorum\'da yanlış yaptığın maddeler burada toplanır.',"go('pekmenu')"));const nb=list.lastElementChild;if(nb)nb.classList.add('activity-card');}}
 if(['mode','boardmode','mcqmode'].includes(st.screen)){const list=app.querySelector('.wrap .list'),ranked=st.screen==='boardmode'?!!RK_SUBJ[st.subject]:st.screen==='mode'?st.op==='kur':RK_BOARDS.some(x=>x.kind==='mcq'&&x.subject===st.subject&&x.group===st.mcqGroup);
  const _pid=!st.guest&&st.prof?rkPid(st.prof):null,_first=ranked&&!st.guest&&!!st.prof&&(!_pid||(!rkProf(_pid).synced&&rkProf(_pid).status==='in'));const note=ranked?'Uyguluyorum sonucun Rekorlarım\'a ve sıralamaya yazılır. Öğreniyorum yazılmaz.'+(_first?' Sıralamada yalnız adın görünür. İstemezsen Rekorlarım ekranından listeden çıkabilirsin.':''):st.screen==='mcqmode'?'Bu bölümün sonucu sıralamaya yazılmaz. Sıralama için “Bütün bölümler” denemesini çöz.':'Bu çalışmanın sonucu sıralamaya yazılmaz.';
  if(list)list.insertAdjacentHTML('afterend','<p class="note">'+note+'</p>');}
 /* Pekiştirme turunun sonunda normal tur başlatan düğmeler gizlenir; dönüş banner'daki düğmelerle yapılır. */
 if(st.pekRound&&st.kDone&&['board','quiz'].includes(st.screen))app.querySelectorAll('button[onclick]').forEach(b=>{if(/startBoard|newKuverBtn|startSession/.test(b.getAttribute('onclick')))b.remove();});
 if(st.sess&&(st.sess.unranked||st.sess.practice==='pek'))app.querySelectorAll('.stats .chip').forEach(c=>{if(/Puan/.test(c.textContent))c.remove();});
 if(['board','quiz','summary','spicereview'].includes(st.screen)){const ban=rkBannerHTML(),tek=rkTekrarHTML(),w=app.querySelector('.wrap')||app.querySelector('.quiz .side');if(w){if(ban)w.insertAdjacentHTML('afterbegin',ban);if(tek)w.insertAdjacentHTML('beforeend',tek);}}
 /* Puansız deneme telefonda da açıkça belirtilir. */
 if(st.screen==='board'&&st.sess&&st.sess.unranked&&!(st.board&&st.board.checked)){const w=app.querySelector('.wrap');if(w)w.insertAdjacentHTML('afterbegin','<p class="card rk-banner" role="status"><strong>Puansız deneme</strong>Bu denemenin sonucu rekora ve sıralamaya yazılmaz.</p>');}
};
window.addEventListener('online',()=>{rkMaintenance();});
setTimeout(()=>{if(Object.keys(rkProfAll()).length||rkQueue().length)rkMaintenance();},1500);
render();
