/* © 2026 Ali Arıkoğlu. Tüm hakları saklıdır. */
/* Çoktan seçmeli sorular: konu (grup) seçimi, kitaptaki sıra, A-B-C-D harfleri ve fotoğraflı seçenekler.
   Kalıcı madde kimlikleri korunur. Sayısal ve alfabetik seçenek sırası sabittir. */
'use strict';
const MCQ_PREV_START=startContent,MCQ_PREV_RENDER=render,MCQ_PREV_QUIZ=contentQuizHTML;
/* Sıralama denemeleri için birleşen gruplar. Ortak hedefi olan küçük gruplar tek deneme olur. */
const MCQ_MERGE={
  'bulasik-makinesi-temizligi':[{label:'Bulaşık Yıkama ve Atık Yönetimi · Bütün bölümler',whole:true,parts:['1. Bölüm','2. Bölüm','3. Bölüm','4. Bölüm','5. Bölüm · Atık yönetimi','Genel tekrar · Set 1','Genel tekrar · Set 2','Genel tekrar · Set 3','Genel tekrar · Set 4']}],
  'baharat':[{label:'Baharatlar · Bütün bölümler',whole:true,parts:['1. Bölüm · Biberler ve toz baharatlar','2. Bölüm · Tohumlar ve kuru baharatlar','3. Bölüm · Taze yapraklı bitkiler','4. Bölüm · Taze ve kuru hâlleri','5. Bölüm · Çiçekler, kökler ve tozlar','6. Bölüm · Meyveler ve kuru meyveler','7. Bölüm · Sert kabuklu yemişler','8. Bölüm · Taze ürünler ve diğerleri','Genel tekrar · Set 1','Genel tekrar · Set 2']}],
  'beslenme-ilkeleri':[{label:'Beslenme İlkeleri · Bütün bölümler',whole:true,parts:['1. Bölüm · Yeterli ve dengeli beslenme','2. Bölüm · Besin ögeleri ve besin grupları','3. Bölüm · Besin seçimi ve porsiyonlar','4. Bölüm · Şekerler, su ve içecekler','5. Bölüm · Alışveriş, etiket ve gıda güvenliği','6. Bölüm · Sürdürülebilir beslenme ve Türk mutfağı','7. Bölüm · Gıda güvenliği ve hijyen','Genel tekrar · Set 1','Genel tekrar · Set 2','Genel tekrar · Set 3','Genel tekrar · Set 4','Genel tekrar · Set 5','Genel tekrar · Set 6']}]
};
/* whole: bölümler yerinde kalır, ayrıca bütün soruları içeren tek deneme listenin sonuna eklenir. */
function mcqGroups(){const d=getData();if(st.op!=='mcq')return [];
  const qs=d.questions||[];if(!qs.some(q=>q.group))return [];
  let list=(d.groups&&d.groups.length?d.groups:[...new Set(qs.map(q=>q.group))].map(g=>({label:g}))).map(g=>({...g,parts:[g.label]}));
  (MCQ_MERGE[st.subject]||[]).forEach(m=>{if(m.whole){list.push({label:m.label,whole:true,parts:m.parts.slice()});return;}const i=list.findIndex(g=>m.parts.includes(g.label));if(i<0)return;const first=list[i];list=list.filter(g=>!m.parts.includes(g.label));list.splice(i,0,{label:m.label,chapter:first.chapter,parts:m.parts.slice()});});
  return list.map(g=>({...g,count:qs.filter(q=>g.parts.includes(q.group)).length})).filter(g=>g.count);}
function mcqGroupParts(label){const g=mcqGroups().find(x=>x.label===label);return g?g.parts:[label];}
/* Uyguluyorum ve Pekiştiriyorum'da sorular ve sırası serbest seçenekler karışır; harfler yeniden eşlenir.
   Öğreniyorum'da kaynak sırası korunur. */
function mcqUnique(items){const seen=new Set();return items.filter(q=>{const key=q.equivalenceKey||q.id;if(seen.has(key))return false;seen.add(key);return true;});}
function mcqPromptHTML(q){let h=esc(q.prompt);for(const word of q.emphasis||[])h=h.replace(esc(word),'<strong class="question-negative">'+esc(word)+'</strong>');return h;}
function mcqShuffled(q){const letters=['A','B','C','D','E','F'];const ch=q.choiceOrder?q.choices.slice():shuffle(q.choices);let correct=q.correct;const choices=ch.map((c,i)=>{const id=letters[i];if(c.id===q.correct)correct=id;return {...c,id};});return {...q,choices,correct};}
function pickGroup(i){const gs=mcqGroups(),g=gs[i];if(g.whole&&mcqKalan(gs).length)return;st.mcqGroup=g.label;go('mcqmode');}
function mcqBegin(mode){st.practice=mode;startContent();}
startContent=function(setNo){
  if(st.op!=='mcq'||!mcqGroups().length)return MCQ_PREV_START(setNo);
  if(!st.mcqGroup){go('content');return;}
  const parts=mcqGroupParts(st.mcqGroup);let items=getData().questions.filter(q=>parts.includes(q.group));
  if(st.practice==='check')items=shuffle(items);
  items=mcqUnique(items);
  if(st.practice==='check')items=items.map(mcqShuffled);
  st.contentItems=items.slice();st.contentIndex=0;st.brk=0;st.kDone=false;st.done=false;st.inBreak=false;st.contentSet=null;
  st.sess={id:Date.now(),p:st.guest?'Misafir':st.prof,t:new Date().toISOString(),op:'mcq',subject:st.subject,practice:st.practice||'learn',total:items.length,group:st.mcqGroup,s:0,ok:0,fix:0,bad:0,br:0,qs:[]};
  st.savedMsg=st.guest?'Misafir oturumu: sonuçlar kaydedilmiyor.':'';contentNext();st.screen='quiz';render();window.scrollTo(0,0);
};
const MCQ_PREV_PICK=pickContent;
pickContent=function(op){st.mcqGroup=null;MCQ_PREV_PICK(op);};
const MCQ_PREV_CAT=catName;
catName=function(r){const s=MCQ_PREV_CAT(r);return r.op==='mcq'&&r.group?s+' · '+r.group:s;};
/* "Bütün bölümler" kilidi: öğrenci diğer bölümlerin hepsini en az bir kez bitirince açılır. Misafirde kayıt tutulmadığı için kilit uygulanmaz. */
function mcqKalan(gs){
  if(st.guest||!st.prof)return [];
  const done=new Set(records().filter(r=>r.p===st.prof&&r.op==='mcq'&&r.subject===st.subject&&r.total>0&&(r.qs||[]).length>=r.total).map(r=>r.group));
  return gs.filter(g=>!g.whole&&!done.has(g.label));
}
function mcqListHTML(){
  const gs=mcqGroups();let h=topBar(subjectName())+'<div class="wrap"><h1>Çoktan Seçmeli Sorular</h1><p class="sub">Bir konu seç.</p>';
  let ch=null;
  gs.forEach((g,i)=>{
    if(g.whole){if(ch!==null)h+='</div>';ch=null;const kal=mcqKalan(gs);h+='<h2 class="grp-h">Bütün bölümler</h2><div class="list set-list grp-list">'+(kal.length?'<div class="menu-btn preparing" aria-disabled="true"><b>🔒 Bütün bölümler</b><span>Kilitli · Önce şu bölümleri bitir: '+kal.length+' bölüm kaldı</span></div>':menuButton('Bütün bölümler',g.count+' soru',"pickGroup("+i+")"))+'</div>';return;}
    if(g.chapter&&g.chapter!==ch){if(ch!==null)h+='</div>';ch=g.chapter;h+='<h2 class="grp-h">'+(g.chapterLabel||ch+'. Bölüm')+'</h2><div class="list set-list grp-list">';}
    h+=menuButton(g.label.replace(/^\d\. Bölüm · /,'').replace(/^Genel tekrar · /,''),g.count+' soru',"pickGroup("+i+")");
  });
  return h+(ch!==null?'</div>':'')+'</div>';
}
contentQuizHTML=function(){
  if(st.op!=='mcq'||!st.q||!st.q.group)return MCQ_PREV_QUIZ();
  const q=st.q;
  let h=topBar(subjectName()+' · '+q.group)+'<div class="wrap">'+statsHtml();
  h+='<section class="card"><h2>'+mcqPromptHTML(q)+'</h2>'+(q.image?'<img class="content-image match-image" src="'+esc(q.image)+'" alt="'+esc(q.imageAlt||'Soru fotoğrafı')+'">':'');
  const pic=q.choices.some(c=>c.image);
  h+='<div class="opts'+(pic?' opts-pic':' opts-mcq')+'">';
  q.choices.forEach(c=>{const dis=st.done||st.tries>=2||st.wrong.includes(c.id);
    h+='<button class="opt'+(st.practice!=='check'&&st.wrong.includes(c.id)?' wrong':'')+(st.practice!=='check'&&st.done&&c.id===q.correct?' right':'')+(st.practice==='check'&&st.done&&c.id===st.secim?' secildi':'')+'" data-choice="'+esc(c.id)+'"'+(dis?' disabled':'')+'>'+
      (c.image?'<img src="'+esc(c.image)+'" alt="'+esc(c.imageAlt||c.id+' seçeneği')+'"><span class="olet">'+esc(c.id)+')</span>':'<span class="olet">'+esc(c.id)+')</span> '+esc(c.text))+'</button>';});
  h+='</div></section>'+msgHtml();
  if(st.done)h+='<button class="btn pri" onclick="nextQ()">Devam</button>';else if(st.tries>=2)h+='<button class="btn pri" onclick="showSol()">Yanıtı Gör</button>';
  return h+footHtml()+'</div>';
};
render=function(){
  if(st.screen==='mcqmode'){document.getElementById('app').innerHTML=topBar(subjectName())+'<div class="wrap"><h1>Nasıl çalışalım?</h1><div class="list">'+menuButton('Öğreniyorum','Yanlışta ipucu ve ikinci deneme var.',"mcqBegin('learn')")+menuButton('Uyguluyorum','Her soruda bir yanıt ver. Açıklamalar çalışma bitince açılır.',"mcqBegin('check')")+'</div></div>';return;}
  if(st.screen==='content'&&st.op==='mcq'&&CONTENT[st.subject]&&mcqGroups().length){document.getElementById('app').innerHTML=mcqListHTML();return;}
  MCQ_PREV_RENDER();
};

/* ---- Bölüm listesi tek ekranda (12.11): kaydırma yok, iç içe açılır ----
   1. katman: bölüm kutuları + "Genel tekrar" + "Bütün bölümler". Birden çok konusu olan bölüm ve Genel tekrar dokununca
   kendi kutularını açar (2. katman). Sıra kilidi: bir bölüm, önceki bölümün bütün konuları bitince açılır; bölüm içindeki
   konular ve tekrar setleri de sırayla açılır. Genel tekrar, bütün bölümler bitince açılır. Misafirde kayıt olmadığı için kilit yok. */
st.mcqKat=null;
function mcqBitenler(){
  if(st.guest||!st.prof)return null;
  return new Set(records().filter(r=>r.p===st.prof&&r.op==='mcq'&&r.subject===st.subject&&r.total>0&&(r.qs||[]).length>=r.total).map(r=>r.group));
}
function mcqKatlar(){
  const gs=mcqGroups().map((g,i)=>({...g,i})),katlar=[],bul=k=>katlar.find(x=>x.key===k);
  gs.forEach(g=>{
    if(g.whole)return;
    const m=/^(\d+)\. Bölüm/.exec(g.label),key=/^Genel tekrar/.test(g.label)?'tekrar':g.chapter?'b'+g.chapter:m?'b'+m[1]:'k'+g.i;
    let k=bul(key);
    if(!k){k={key,gruplar:[],tekrar:key==='tekrar',ad:key==='tekrar'?'Genel tekrar':key[0]==='b'?key.slice(1)+'. Bölüm':g.label};katlar.push(k);}
    k.gruplar.push(g);
  });
  const tekrar=katlar.filter(k=>k.tekrar),bolum=katlar.filter(k=>!k.tekrar);
  return {liste:bolum.concat(tekrar),butun:gs.find(g=>g.whole)||null};
}
function mcqAltAd(g){return g.label.replace(/^\d+\. Bölüm · /,'').replace(/^Genel tekrar · /,'');}
function mcqKatDurum(){
  const {liste,butun}=mcqKatlar(),bit=mcqBitenler(),ok=g=>!bit||bit.has(g.label);
  let onceki=true;
  liste.forEach(k=>{
    k.bitti=k.gruplar.every(ok);
    k.acik=!bit||(k.tekrar?liste.filter(x=>!x.tekrar).every(x=>x.bitti):onceki);
    if(!k.tekrar)onceki=k.acik&&k.bitti;
    let og=k.acik;k.gruplar.forEach(g=>{g.bitti=ok(g)&&!!bit;g.acik=og;og=og&&ok(g);});
  });
  const butunAcik=!bit||liste.every(k=>k.gruplar.every(ok));
  return {liste,butun,butunAcik};
}
function mcqKutu(baslik,alt,durum,onclick){
  const ik={bitti:'✓',kilit:'🔒',sirada:'▶',acik:''}[durum]||'';
  const etk={bitti:'Tamamlandı',kilit:'Kilitli',sirada:'Sıradaki',acik:''}[durum]||'';
  return '<button type="button" class="mq-kutu mq-'+durum+'"'+(durum==='kilit'?' disabled aria-disabled="true"':' onclick="'+onclick+'"')+
    ' aria-label="'+esc(baslik+(alt?'. '+alt:'')+(etk?'. '+etk:''))+'"><b>'+esc(baslik)+'</b>'+(alt?'<span>'+esc(alt)+'</span>':'')+
    (ik?'<i aria-hidden="true">'+ik+'</i>':'')+'</button>';
}
window.mcqKatAc=function(key){st.mcqKat=key;render();};
mcqListHTML=function(){
  const {liste,butun,butunAcik}=mcqKatDurum(),kat=st.mcqKat&&liste.find(k=>k.key===st.mcqKat);
  let siradaVar=false;const durum=(acik,bitti)=>!acik?'kilit':bitti?'bitti':(!siradaVar&&(siradaVar=true))?'sirada':'acik';
  let kutular,baslik,alt;
  if(kat){
    baslik=kat.ad;alt=kat.tekrar?'Setler sırayla açılır.':'Konular sırayla açılır.';
    kutular=kat.gruplar.map(g=>mcqKutu(mcqAltAd(g),g.count+' soru',durum(g.acik,g.bitti),'pickGroup('+g.i+')'));
  }else{
    baslik='Çoktan Seçmeli Sorular';alt='Bölümler sırayla açılır.';
    kutular=liste.map(k=>{
      const tek=k.gruplar.length===1&&!k.tekrar,g=k.gruplar[0];
      const ad=k.tekrar?'Genel tekrar':k.key[0]==='b'?k.ad:mcqAltAd(g);
      const altYazi=tek?(k.key[0]==='b'?mcqAltAd(g)+' · ':'')+g.count+' soru':k.gruplar.length+(k.tekrar?' set':' konu');
      return mcqKutu(ad,altYazi,durum(k.acik,k.bitti&&!!mcqBitenler()),tek?'pickGroup('+g.i+')':"mcqKatAc('"+k.key+"')");
    });
    if(butun)kutular.push(mcqKutu('Bütün bölümler',butun.count+' soru',butunAcik?'acik':'kilit','pickGroup('+butun.i+')'));
  }
  const n=kutular.length,sut=n<=4?1:n<=10?2:3;
  return topBar(subjectName())+'<div class="wrap mq-ekran"><h1>'+esc(baslik)+'</h1><p class="sub">'+esc(alt)+'</p>'+
    '<div class="mq-izgara" style="--sut:'+sut+';--sat:'+Math.ceil(n/sut)+'">'+kutular.join('')+'</div></div>';
};
{const MQ_BACK=back;back=function(){if(st.screen==='content'&&st.op==='mcq'&&st.mcqKat){st.mcqKat=null;render();return;}MQ_BACK();};}
{const MQ_PICK=pickContent;pickContent=function(op){st.mcqKat=null;MQ_PICK(op);};}
